create definer = root@localhost trigger `add free seat`
    before delete
    on tickets
    for each row
begin
    UPDATE sessions
    set Number_of_free_seats = Number_of_free_seats + 1
    where Old.Session_id = sessions.Session_id;
end;

