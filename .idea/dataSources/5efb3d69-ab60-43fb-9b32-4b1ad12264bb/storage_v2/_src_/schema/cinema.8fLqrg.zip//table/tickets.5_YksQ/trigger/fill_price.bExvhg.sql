create definer = root@localhost trigger `fill price`
    before insert
    on tickets
    for each row
BEGIN
    Set new.Price = 50 + 5 * new.Place_row +
                    5 * (select Hour(Session_full_date) from Sessions where session_id = new.session_id) +
                    20 * (select ThreeD_Supporting from Sessions where session_id = new.session_id);
end;

