create definer = root@localhost trigger `reduce free seat`
    after insert
    on tickets
    for each row
begin
    UPDATE sessions
    set Number_of_free_seats = Number_of_free_seats - 1
    where NEW.Session_id = sessions.Session_id;
end;

